$( function () {

	// hamburger
	$('.hamburger').click(function() {
		$('.menu-collapse').toggleClass('d-none').css('order', '1');
		$('.main-menu__list').toggleClass('menu-opened');
	});

	//кнопку плавной прокрутки "Подробнее"
	$('a.go-to').click(function(e) {
		e.preventDefault();
		elementClick = $(this).attr('href');
		destination = $(elementClick).offset().top;
		$('body,html').animate({scrollTop: destination}, 800);
	});

	// Всплывающее окно
	$('.modall').click(function(e) {
		e.preventDefault();
		$('#exampleModal').arcticmodal();
	});
	// Всплывающее окно
	$('.modall1').click(function(e) {
		e.preventDefault();
		$('#exampleModal1').arcticmodal();
	});
	// Всплывающее окно
	$('.modall2').click(function(e) {
		e.preventDefault();
		$('#exampleModal2').arcticmodal();
	});
	// Всплывающее окно
	$('.modall3').click(function(e) {
		e.preventDefault();
		$('#exampleModal3').arcticmodal();
	});
	// Всплывающее окно
	$('.modall4').click(function(e) {
		e.preventDefault();
		$('#exampleModal4').arcticmodal();
	});
	// Всплывающее окно
	$('.modall5').click(function(e) {
		e.preventDefault();
		$('#exampleModal5').arcticmodal();
	});

	$(window).scroll(function() {
		if ($(this).scrollTop() > 700){
			$('nav').addClass("sticky");
		}
		else{
			$('nav').removeClass("sticky");
		}
	});


var selectedClass = "";
$(".filter").click(function(){
selectedClass = $(this).attr("data-rel");
$("#gallery").fadeTo(100, 0.1);
$("#gallery div").not("."+selectedClass).fadeOut().removeClass('animation');
setTimeout(function() {
$("."+selectedClass).fadeIn().addClass('animation');
$("#gallery").fadeTo(300, 1);
}, 300);
});


});
